# Techno World Radio

App Android para escuchar radios de todo el mundo con música techno / electrónica desde los 80 hasta la actualidad.
Filtros por subgénero y época, dial de colores, reproducción en segundo plano.

## Cómo obtener el APK
1. Subí este proyecto a un repo de GitHub (el zip tal cual + el archivo `.github/workflows/build.yml`, o los archivos descomprimidos).
2. Pestaña **Actions**: el workflow "Compilar APK" corre solo en cada subida (5–8 min).
3. Bajá `TechnoWorldRadio.apk` desde **Releases** (o desde Artifacts) e instalalo en el móvil.
