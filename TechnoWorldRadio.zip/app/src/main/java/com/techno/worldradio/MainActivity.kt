package com.techno.worldradio

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

val Cyan = Color(0xFF00E5FF)
val Pink = Color(0xFFFF2E93)
val Yellow = Color(0xFFFFE600)
val NeonGreen = Color(0xFF39FF14)
val Violet = Color(0xFFB388FF)
val BgTop = Color(0xFF12002B)
val BgBottom = Color(0xFF05010F)
val PALETTE = listOf(Cyan, Pink, Yellow, NeonGreen, Violet)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Pink, secondary = Cyan)) {
                NotificationPermissionRequest()
                RadioScreen()
            }
        }
    }
}

@Composable
fun NotificationPermissionRequest() {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}

@Composable
fun RadioScreen(vm: RadioViewModel = viewModel()) {
    val focus = LocalFocusManager.current
    val idx = vm.stations.indexOfFirst { it.url == vm.current?.url }
    val progress = if (idx >= 0 && vm.stations.size > 1) idx / (vm.stations.size - 1f) else 0.5f

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
            .statusBarsPadding()
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text("TECHNO", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Spacer(Modifier.width(8.dp))
            Text("WORLD RADIO", color = Pink, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        }
        Text(
            "Del 80 a hoy · emisoras de todo el mundo",
            color = Color(0xAAFFFFFF),
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 16.dp, bottom = 4.dp)
        )

        Dial(
            progress = progress,
            playing = vm.isPlaying,
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(horizontal = 24.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(GENRES) { i, g ->
                NeonChip(g.label, g == vm.genre, PALETTE[i % PALETTE.size]) { vm.selectGenre(g) }
            }
        }
        Spacer(Modifier.height(8.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { NeonChip("Todas", vm.era == null, Yellow) { vm.selectEra(null) } }
            items(ERAS) { e ->
                NeonChip(e.label, vm.era == e, Yellow) { vm.selectEra(e) }
            }
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            placeholder = { Text("Buscar emisora, ciudad…", color = Color(0x99FFFFFF)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Cyan) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                vm.load()
                focus.clearFocus()
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Cyan,
                unfocusedBorderColor = Color(0x55FFFFFF),
                cursorColor = Cyan
            ),
            shape = RoundedCornerShape(50)
        )

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when {
                vm.loading -> CircularProgressIndicator(
                    color = Cyan,
                    modifier = Modifier.align(Alignment.Center)
                )

                vm.message != null -> Column(
                    Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(vm.message ?: "", color = Color.White, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { vm.load() },
                        colors = ButtonDefaults.buttonColors(containerColor = Pink)
                    ) { Text("Reintentar") }
                }

                else -> LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(vm.stations, key = { it.url }) { s ->
                        StationRow(
                            s = s,
                            selected = s.url == vm.current?.url,
                            playing = vm.isPlaying && s.url == vm.current?.url
                        ) { vm.play(s) }
                    }
                }
            }
        }

        PlayerBar(vm)
    }
}

@Composable
fun Dial(progress: Float, playing: Boolean, modifier: Modifier = Modifier) {
    val needle by animateFloatAsState(targetValue = progress, animationSpec = tween(700), label = "needle")
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "glow"
    )
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height * 0.94f
        val r = min(size.width * 0.46f, size.height * 0.88f)

        drawArc(
            color = Color(0x33FFFFFF),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(cx - r * 0.66f, cy - r * 0.66f),
            size = Size(r * 1.32f, r * 1.32f),
            style = Stroke(width = 3f)
        )

        val ticks = 61
        for (i in 0 until ticks) {
            val t = i / (ticks - 1f)
            val a = Math.toRadians(180.0 + 180.0 * t)
            val long = i % 5 == 0
            val inner = r * (if (long) 0.76f else 0.85f)
            drawLine(
                color = Color.hsv(t * 300f, 0.85f, 1f),
                start = Offset(cx + (cos(a) * inner).toFloat(), cy + (sin(a) * inner).toFloat()),
                end = Offset(cx + (cos(a) * r).toFloat(), cy + (sin(a) * r).toFloat()),
                strokeWidth = if (long) 5f else 2.5f,
                cap = StrokeCap.Round
            )
        }

        val na = Math.toRadians(180.0 + 180.0 * needle)
        val tip = Offset(cx + (cos(na) * r * 0.9f).toFloat(), cy + (sin(na) * r * 0.9f).toFloat())
        drawLine(Pink, Offset(cx, cy), tip, strokeWidth = 6f, cap = StrokeCap.Round)
        drawCircle(Pink.copy(alpha = if (playing) glow else 0.35f), radius = 26f, center = Offset(cx, cy))
        drawCircle(Yellow, radius = 10f, center = Offset(cx, cy))
    }
}

@Composable
fun NeonChip(text: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) color else Color(0x22FFFFFF))
            .border(1.dp, color, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text,
            color = if (selected) Color.Black else color,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
fun StationRow(s: Station, selected: Boolean, playing: Boolean, onClick: () -> Unit) {
    val accent = Color.hsv((abs(s.name.hashCode()) % 360).toFloat(), 0.7f, 1f)
    val shape = RoundedCornerShape(16.dp)
    val sub = listOf(
        s.country,
        s.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(", "),
        if (s.bitrate > 0) s.bitrate.toString() + " kbps" else ""
    ).filter { it.isNotBlank() }.joinToString(" · ")

    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Color(0x33FF2E93) else Color(0x14FFFFFF))
            .border(1.dp, if (selected) Pink else Color(0x22FFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(accent),
            contentAlignment = Alignment.Center
        ) {
            Text(s.name.first().uppercase(), color = Color.Black, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.name,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                sub,
                color = Color(0xAAFFFFFF),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (playing) {
            Text("▶", color = Pink, fontSize = 18.sp)
        }
    }
}

@Composable
fun PlayerBar(vm: RadioViewModel) {
    val cur = vm.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF1B0640))
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                cur?.name ?: "Elegí una emisora",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val sub = when {
                cur == null -> "Tocá una de la lista para escuchar"
                vm.buffering -> "Conectando…"
                vm.nowPlaying.isNotBlank() -> vm.nowPlaying
                else -> cur.country
            }
            Text(
                sub,
                color = Cyan,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = { vm.previous() }) {
            Icon(Icons.Filled.SkipPrevious, contentDescription = "Anterior", tint = Color.White)
        }
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Pink)
                .clickable { if (cur != null) vm.toggle() },
            contentAlignment = Alignment.Center
        ) {
            if (vm.buffering) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(28.dp))
            } else {
                Icon(
                    if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Reproducir / pausar",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
        IconButton(onClick = { vm.next() }) {
            Icon(Icons.Filled.SkipNext, contentDescription = "Siguiente", tint = Color.White)
        }
    }
}
