package com.techno.worldradio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Station(
    val id: String,
    val name: String,
    val url: String,
    val country: String,
    val tags: String,
    val bitrate: Int,
    val codec: String
)

data class Genre(val label: String, val tag: String)
data class Era(val label: String, val tag: String, val nameTerm: String)

val GENRES = listOf(
    Genre("Techno", "techno"),
    Genre("House", "house"),
    Genre("Deep House", "deep house"),
    Genre("Trance", "trance"),
    Genre("Electro", "electro"),
    Genre("Synthwave", "synthwave"),
    Genre("Eurodance", "eurodance"),
    Genre("EDM", "edm"),
    Genre("Drum & Bass", "drum and bass"),
    Genre("Hardstyle", "hardstyle"),
    Genre("Acid", "acid"),
    Genre("Minimal", "minimal"),
    Genre("Italo Disco", "italo disco"),
    Genre("Electrónica", "electronic")
)

val ERAS = listOf(
    Era("Años 80", "80s", "80s"),
    Era("Años 90", "90s", "90s"),
    Era("2000s", "2000s", "2000"),
    Era("2010s", "2010s", "2010"),
    Era("Actual", "2020s", "2020")
)

/** Usa la API pública y gratuita de radio-browser.info */
object RadioApi {
    private val hosts = listOf(
        "de1.api.radio-browser.info",
        "nl1.api.radio-browser.info",
        "at1.api.radio-browser.info"
    )

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun search(tags: List<String>, name: String = ""): List<Station> =
        withContext(Dispatchers.IO) {
            val sb = StringBuilder("/json/stations/search?hidebroken=true&order=clickcount&reverse=true&limit=80")
            sb.append("&tagList=").append(enc(tags.joinToString(",")))
            if (name.isNotBlank()) sb.append("&name=").append(enc(name))
            var last: Exception? = null
            for (h in hosts) {
                try {
                    val body = get("https://" + h + sb.toString())
                    return@withContext parse(body)
                } catch (e: Exception) {
                    last = e
                }
            }
            throw IOException("sin conexión", last)
        }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "TechnoWorldRadio/1.0")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun parse(json: String): List<Station> {
        val arr = JSONArray(json)
        val out = ArrayList<Station>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }
            if (url.isBlank()) continue
            out.add(
                Station(
                    id = o.optString("stationuuid"),
                    name = o.optString("name").trim().ifBlank { "Emisora sin nombre" },
                    url = url,
                    country = o.optString("country"),
                    tags = o.optString("tags"),
                    bitrate = o.optInt("bitrate"),
                    codec = o.optString("codec")
                )
            )
        }
        return out.distinctBy { it.url }
    }
}
