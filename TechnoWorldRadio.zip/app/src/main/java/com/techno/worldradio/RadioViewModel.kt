package com.techno.worldradio

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class RadioViewModel(app: Application) : AndroidViewModel(app) {

    var genre by mutableStateOf(GENRES.first()); private set
    var era by mutableStateOf<Era?>(null); private set
    var query by mutableStateOf("")
    var stations by mutableStateOf<List<Station>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set
    var current by mutableStateOf<Station?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var nowPlaying by mutableStateOf(""); private set

    private var controller: MediaController? = null
    private var job: Job? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            this@RadioViewModel.isPlaying = isPlaying
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            buffering = playbackState == Player.STATE_BUFFERING
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            val t = mediaMetadata.title?.toString().orEmpty()
            nowPlaying = if (t == current?.name) "" else t
        }

        override fun onPlayerError(error: PlaybackException) {
            buffering = false
            nowPlaying = "No se pudo reproducir. Probá otra emisora."
        }
    }

    init {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, RadioService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                isPlaying = c.isPlaying
            } catch (e: Exception) {
                // sin controlador: la UI sigue funcionando para buscar
            }
        }, ContextCompat.getMainExecutor(ctx))
        load()
    }

    fun selectGenre(g: Genre) {
        genre = g
        load()
    }

    fun selectEra(e: Era?) {
        era = e
        load()
    }

    fun load() {
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            message = null
            try {
                val q = query.trim()
                val e = era
                var list = RadioApi.search(
                    if (e != null) listOf(genre.tag, e.tag) else listOf(genre.tag),
                    q
                )
                if (e != null && q.isEmpty() && list.size < 6) {
                    val extra = RadioApi.search(listOf(genre.tag), e.nameTerm)
                    list = (list + extra).distinctBy { it.url }
                }
                stations = list
                if (list.isEmpty()) message = "No encontré emisoras con ese filtro. Probá otro."
            } catch (ce: CancellationException) {
                throw ce
            } catch (ex: Exception) {
                stations = emptyList()
                message = "Sin conexión. Revisá internet y reintentá."
            }
            loading = false
        }
    }

    fun play(s: Station) {
        current = s
        nowPlaying = ""
        val c = controller ?: return
        val item = MediaItem.Builder()
            .setUri(s.url)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(s.name)
                    .setArtist(s.country)
                    .build()
            )
            .build()
        c.setMediaItem(item)
        c.prepare()
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() = step(1)
    fun previous() = step(-1)

    private fun step(d: Int) {
        val list = stations
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.url == current?.url }
        val n = if (i < 0) 0 else (i + d + list.size) % list.size
        play(list[n])
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
